Figma file used in the lesson: https://www.figma.com/design/q1erxUgupZrnCMZL8T6luI/Responsive-Design?node-id=1156-718&t=DG0QhaseOpcN42cJ-1
Password: lesson-9